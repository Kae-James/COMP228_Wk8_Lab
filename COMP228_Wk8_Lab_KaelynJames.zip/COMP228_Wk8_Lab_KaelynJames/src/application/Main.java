// This program makes a college student registration window
package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

// Create Main class that extends Application
public class Main extends Application {

	// Method (holds all parts of the window)
	@Override
	public void start(Stage stage) {

		// TOP: HBox holds the big application title and a small user label
		// Create big application title text
		Label title = new Label("College Student Services");
		// Add style
		title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

		// Create label for right side of header
		Label userLabel = new Label("JavaFX Layouts Lab");

		// The empty Region in the middle stretches and pushes userLabel to the right
		HBox header = new HBox(title, new Region(), userLabel);
		HBox.setHgrow(header.getChildren().get(1), Priority.ALWAYS);
		// Lines everything in the middle (starts from left)
		header.setAlignment(Pos.CENTER_LEFT);
		header.setPadding(new Insets(15));
		header.setStyle("-fx-background-color: #B880C0;");

		// LEFT: VBox stacks navigation buttons vertically
		// Create MENU label above buttons
		Label menuTitle = new Label("MENU");
		// Add style
		menuTitle.setStyle("-fx-font-weight: bold;");
		// Create four menu buttons
		Button dashboardButton = new Button("Dashboard");
		Button registrationButton = new Button("Registration");
		Button coursesButton = new Button("Courses");
		Button helpButton = new Button("Help");

		// Create VBox
		VBox navigation = new VBox(12,
				menuTitle, dashboardButton, registrationButton,
				coursesButton, helpButton);
		navigation.setPadding(new Insets(15));
		navigation.setStyle("-fx-background-color: #f4f4f4;");

		// CENTER: GridPane aligns labels and input controls in rows
		// Create heading above the form
		Label formTitle = new Label("Student Registration");
		formTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

		// Create text box for id
		TextField idField = new TextField();
		idField.setPromptText("e.g. S1001");
		// Create text box for name
		TextField nameField = new TextField();
		nameField.setPromptText("Enter full name");
		// Create text box for email
		TextField emailField = new TextField();
		emailField.setPromptText("name@example.com");

		// Create ComboBox (drop-down list)
		ComboBox<String> programBox = new ComboBox<>();
		programBox.getItems().addAll(
				"Cybersecurity",
				"Software Engineering",
				"Game Programming",
				"Information Technology",
				"Cloud Computing");
		programBox.setPromptText("Select a program");

		// Create GridPane
		GridPane form = new GridPane();
		// Set H and V gaps
		form.setHgap(12);
		form.setVgap(14);
		// Add labels
		form.add(new Label("Student ID:"), 0, 0);
		form.add(idField, 1, 0);
		form.add(new Label("Full Name:"), 0, 1);
		form.add(nameField, 1, 1);
		form.add(new Label("Email:"), 0, 2);
		form.add(emailField, 1, 2);
		form.add(new Label("Program:"), 0, 3);
		form.add(programBox, 1, 3);

		// Rule for Column 0 (labels) is that it is always at least 100 pixels wide
		ColumnConstraints labelColumn = new ColumnConstraints();
		labelColumn.setMinWidth(100);
		// Rule for Column 1 (inputs) is that it grows to fill extra spaces
		ColumnConstraints inputColumn = new ColumnConstraints();
		inputColumn.setHgrow(Priority.ALWAYS);
		form.getColumnConstraints().addAll(labelColumn, inputColumn);

		// BUTTON ROW: HBox places action buttons side by side
		// Create instruction label
		Label statusLabel = new Label("Complete the form and select Register.");
		// Action buttons
		Button registerButton = new Button("Register");
		Button clearButton = new Button("Clear");
		HBox actions = new HBox(10, registerButton, clearButton);
		actions.setAlignment(Pos.CENTER_LEFT);

		// VBox groups the center content vertically
		VBox centerContent = new VBox(18, formTitle, form, actions, statusLabel);
		centerContent.setPadding(new Insets(25));
		centerContent.setMaxWidth(620);

		// REGISTER: check the required fields
		// When register button is clicked, this part runs
		registerButton.setOnAction(event -> {
			String id = idField.getText().trim();
			String name = nameField.getText().trim();
			String email = emailField.getText().trim();
			String program = programBox.getValue();
			// Validation (checks if any fields are empty)
			if (id.isEmpty() || name.isEmpty() || email.isEmpty() || program == null) {
				// Red error message
				statusLabel.setText("Error: Please complete all fields.");
				statusLabel.setStyle("-fx-text-fill: red;");
			} else {
				// Green success message
				statusLabel.setText("Success: " + name + " (" + id + ") is registered in " + program + ".");
				statusLabel.setStyle("-fx-text-fill: green;");
			}
		});

		// CLEAR: button to reset every field and the status message
		// When clear button is clicked, this part runs
		clearButton.setOnAction(event -> {
			idField.clear();
			nameField.clear();
			emailField.clear();
			programBox.setValue(null);
			statusLabel.setText("Complete the form and select Register.");
			statusLabel.setStyle("");
		});

		// ROOT: BorderPane as the root layout
		BorderPane root = new BorderPane();
		root.setTop(header);
		root.setLeft(navigation);
		root.setCenter(centerContent);

		// Holds everything in the window
		Scene scene = new Scene(root, 760, 450);
		stage.setTitle("College Student Registration");
		stage.setScene(scene);
		stage.show();
	}

	// Starts everything
	public static void main(String[] args) {
		launch(args);
	}
}