module COMP228_Wk8_Lab_KaelynJames {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
